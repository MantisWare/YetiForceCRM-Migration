<?php


//This file contains the commonly used variables 

$parent_tab_info_array=array(1=>'My Home Page',2=>'Marketing',3=>'Sales',4=>'Support',5=>'Analytics',6=>'Inventory',7=>'Tools',8=>'Settings');


$parent_child_tab_rel_array=array(1=>array(3,9,28,),2=>array(26,6,4,28,7,9,8,),3=>array(7,6,4,2,20,22,23,19,8,9,70,70,71,71,),4=>array(13,15,6,4,8,28,9,34,41,42,43,59,),5=>array(25,1,),6=>array(14,18,19,21,22,20,23,35,37,),7=>array(24,27,8,33,40,44,45,47,48,49,51,54,57,58,60,61,62,62,63,63,64,64,65,65,66,66,67,67,68,68,69,69,),8=>array(),);



?>