<?php
/*
List of active services. To enable you must uncomment the appropriate line.
*/
$enabledServices = array(
	//'customerportal',
	//'mobile',
	//'yetiportal',
	//'firefox',
	//'wordplugin',
	//'thunderbird',
);